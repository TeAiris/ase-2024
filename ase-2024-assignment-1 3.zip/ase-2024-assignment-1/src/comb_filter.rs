pub struct CombFilter {
    filter_type: FilterType,
    max_delay_samples: usize,
    delay_line: Vec<Vec<f32>>,
    gain: f32,
    sample_rate_hz: f32,
}

#[derive(Debug, Clone, Copy)]
pub enum FilterType {
    FIR,
    IIR,
}

#[derive(Debug, Clone, Copy)]
pub enum FilterParam {
    Gain,
    Delay,
}

#[derive(Debug, Clone)]
pub enum Error {
    InvalidValue { param: FilterParam, value: f32 },
}

impl CombFilter {
    pub fn new(filter_type: FilterType, max_delay_secs: f32, sample_rate_hz: f32, num_channels: usize) -> Self {
        let max_delay_samples = (max_delay_secs * sample_rate_hz) as usize;
        let delay_line = vec![vec![0.0; max_delay_samples]; num_channels];
        let gain = 1.0;
        CombFilter {
            filter_type,
            max_delay_samples,
            delay_line,
            gain,
            sample_rate_hz,
        }
    }

    pub fn reset(&mut self) {
        for channel in self.delay_line.iter_mut() {
            for sample in channel.iter_mut() {
                *sample = 0.0;
            }
        }
    }

    pub fn process(&mut self, input: &[&[f32]], output: &mut [&mut [f32]]) {
        for (channel_idx, (input_channel, output_channel)) in input.iter().zip(output.iter_mut()).enumerate() {
            for (input_sample, output_sample) in input_channel.iter().zip(output_channel.iter_mut()) {
                let delayed_sample = self.delay_line[channel_idx][0];
                *output_sample = delayed_sample;
                // Shift samples in delay line
                for i in (1..self.max_delay_samples).rev() {
                    self.delay_line[channel_idx][i] = self.delay_line[channel_idx][i - 1];
                }
                // Update delayed sample
                self.delay_line[channel_idx][0] = *input_sample + self.gain * delayed_sample;
            }
        }
    }

    pub fn set_param(&mut self, param: FilterParam, value: f32) -> Result<(), Error> {
        match param {
            FilterParam::Gain => {
                if value >= 0.0 {
                    self.gain = value;
                    Ok(())
                } else {
                    Err(Error::InvalidValue {
                        param: FilterParam::Gain,
                        value,
                    })
                }
            }
            FilterParam::Delay => {
                let max_delay_secs = self.max_delay_samples as f32 / self.sample_rate_hz;
                if value >= 0.0 && value <= max_delay_secs {
                    // Adjust delay line length
                    let new_max_delay_samples = (value * self.sample_rate_hz) as usize;
                    self.max_delay_samples = new_max_delay_samples;
                    // Resize and reset delay line
                    for channel in self.delay_line.iter_mut() {
                        channel.resize(new_max_delay_samples, 0.0);
                    }
                    self.reset();
                    Ok(())
                } else {
                    Err(Error::InvalidValue {
                        param: FilterParam::Delay,
                        value,
                    })
                }
            }
        }
    }

    pub fn get_param(&self, param: FilterParam) -> f32 {
        match param {
            FilterParam::Gain => self.gain,
            FilterParam::Delay => self.max_delay_samples as f32 / self.sample_rate_hz,
        }
    }
}


// TODO: feel free to define other types (here or in other modules) for your own use

// possible test, test the half period of a sine way. It should be 0 

//possible test, feed nothing in , the output should be 0 

// (a-b).abs()< epsilion    .00001

